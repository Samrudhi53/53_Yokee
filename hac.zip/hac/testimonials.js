const testimonials = [
    {
        quote: "our company, we do ongoing research with our target audience. This includes 30-45 minute phone interviews. It was difficult to conduct the interview, really listen, and ask good follow up questions.",
        avatar: "avatar1",
        name: "Diana Ayi",
        title: "Musician"
    },
    {
        quote: "our company, we do ongoing research with our target audience. This includes 30-45 minute phone interviews. It was difficult to conduct the interview, really listen, and ask good follow up questions.",
        avatar: "avatar2",
        name: "Ernest Achiever",
        title: "Web Developer"
    },
    {
        quote: "our company, we do ongoing research with our target audience. This includes 30-45 minute phone interviews. It was difficult to conduct the interview, really listen, and ask good follow up questions.",
        avatar: "avatar3",
        name: "Asamoah Gyan",
        title: "Footerballer"
    },
    {
        quote: "our company, we do ongoing research with our target audience. This includes 30-45 minute phone interviews. It was difficult to conduct the interview, really listen, and ask good follow up questions.",
        avatar: "avatar4",
        name: "Beatrice Aku",
        title: "Politician"
    }

]